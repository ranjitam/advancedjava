app.controller("myController",function($scope,$http)
		{
	
		$http.get( 'http://localhost:8080/ProductManagementSystemPhase3/CategoryJson').success(function(response)
				{
			 
			$scope.category = response;
				});
		$http.get( 'http://localhost:8080/ProductManagementSystemPhase3/CategoryJson').error(function(errormsg) {
					$scope.category = errormsg;
				});

	
		
		$http.get('http://localhost:8080/ProductManagementSystemPhase3/SupplierJson').success(function(response)
				{
			$scope.supplier = response;
				})
				$http.get('http://localhost:8080/ProductManagementSystemPhase3/SupplierJson').error(function(errormsg) {
					$scope.supplier = errormsg;
				});

		
		$http.get( 'http://localhost:8080/ProductManagementSystemPhase3/SubCategoryJson').success(function(response)
				{
			 
			$scope.subcategory = response;
				});
		$http.get( 'http://localhost:8080/ProductManagementSystemPhase3/SubCategoryJson').error(function(errormsg) {
					$scope.subcategory = errormsg;
				});
		
		$http.get( 'http://localhost:8080/ProductManagementSystemPhase3/DiscountJson').success(function(response)
				{
			 
			$scope.discount = response;
				});
		$http.get( 'http://localhost:8080/ProductManagementSystemPhase3/DiscountJson').error(function(errormsg) {
					$scope.discount = errormsg;
				});
	 
		});

