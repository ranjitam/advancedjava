package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForJdbc;
import com.flp.pms.domain.Discount;
import com.google.gson.Gson;

 
public class DiscountJson extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("application/json");
		 PrintWriter out=response.getWriter();
		
		IProductDao db=new ProductDaoImplForJdbc();
		 List<Discount> discounts=db.getAllDiscount();
		 Gson myJson=new Gson();
		 String discount=myJson.toJson(discounts);
		 out.println(discount);
	}

}
