package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

  
public class SearchProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 IProductService iproductservice=new ProductServiceImpl();
	 PrintWriter out=response.getWriter();
	 String option=request.getParameter("option");
	 String search=request.getParameter("search");
	 response.setContentType("text/html"); 
	 		 
	 if(option.equals("ProductName")){
		 Product products=iproductservice.searchByProductName(search);
		 Gson myJson=new Gson();
		 String projson=myJson.toJson(products);
		 iproductservice.storeJson(projson);
		 response.sendRedirect("pages/SearchResult.html");	 
	 }
	 
	 if(option.equals("SupplierName")){
		 Product products=iproductservice.searchBySupplierName(search);
		 Gson myJson=new Gson();
		 String projson=myJson.toJson(products);
		 iproductservice.storeJson(projson);
		 response.sendRedirect("pages/SearchResult.html");	 
	 }
	 
	 if(option.equals("CategoryName")){
		 Product products=iproductservice.searchByCategoryName(search);
		 Gson myJson=new Gson();
		 String projson=myJson.toJson(products);
		 iproductservice.storeJson(projson);
		 response.sendRedirect("pages/SearchResult.html");	 
	 }
	 if(option.equals("SubCategoryName")){
		 Product products=iproductservice.searchBySubCategoryName(search);
		 Gson myJson=new Gson();
		 String projson=myJson.toJson(products);
		 iproductservice.storeJson(projson);
		 response.sendRedirect("pages/SearchResult.html");	 
	 }
	 
	 if(option.equals("Rating")){
		 Product products=iproductservice.searchByRating(Float.parseFloat(search));
		 Gson myJson=new Gson();
		 String projson=myJson.toJson(products);
		 iproductservice.storeJson(projson);
		 response.sendRedirect("pages/SearchResult.html");	 
	 }
	}

}
