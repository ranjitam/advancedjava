package com.flp.pms.domain;

import java.util.Date;

public class Discount
{
	//Discount instance variables
private int discount_Id;
private String discount_Name;
private String description;
private double discount_Percentage;
private Date validThru;

//No argument constructor
public Discount() 
{
	
}

//Argument constructor
public Discount(int discount_Id, String discount_Name, String description, double discount_Percentage, Date validThru) {
	super();
	this.discount_Id = discount_Id;
	this.discount_Name = discount_Name;
	this.description = description;
	this.discount_Percentage = discount_Percentage;
	this.validThru = validThru;
}

//Getter and Setter method
public int getDiscount_Id() {
	return discount_Id;
}
public void setDiscount_Id(int discount_Id) {
	this.discount_Id = discount_Id;
}
public String getDiscount_Name() {
	return discount_Name;
}
public void setDiscount_Name(String discount_Name) {
	this.discount_Name = discount_Name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public double getDiscount_Percentage() {
	return discount_Percentage;
}
public void setDiscount_Percentage(double discount_Percentage) {
	this.discount_Percentage = discount_Percentage;
}
public Date getValidThru() {
	return validThru;
}
public void setValidThru(Date validThru) {
	this.validThru = validThru;
}



//Hashcode and Equals method 

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((description == null) ? 0 : description.hashCode());
	result = prime * result + discount_Id;
	result = prime * result + ((discount_Name == null) ? 0 : discount_Name.hashCode());
	long temp;
	temp = Double.doubleToLongBits(discount_Percentage);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	result = prime * result + ((validThru == null) ? 0 : validThru.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Discount other = (Discount) obj;
	if (description == null) {
		if (other.description != null)
			return false;
	} else if (!description.equals(other.description))
		return false;
	if (discount_Id != other.discount_Id)
		return false;
	if (discount_Name == null) {
		if (other.discount_Name != null)
			return false;
	} else if (!discount_Name.equals(other.discount_Name))
		return false;
	if (Double.doubleToLongBits(discount_Percentage) != Double.doubleToLongBits(other.discount_Percentage))
		return false;
	if (validThru == null) {
		if (other.validThru != null)
			return false;
	} else if (!validThru.equals(other.validThru))
		return false;
	return true;
}

@Override
public String toString() {
	return "Discount [discount_Id=" + discount_Id + ", discount_Name=" + discount_Name + ", description=" + description
			+ ", discount_Percentage=" + discount_Percentage + ", validThru=" + validThru + "]";
}

}
