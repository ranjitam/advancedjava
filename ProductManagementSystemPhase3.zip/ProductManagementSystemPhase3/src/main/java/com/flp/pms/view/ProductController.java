package com.flp.pms.view;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForJdbc;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;


public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		 IProductService iProductService=new ProductServiceImpl();
	 
		 
		 String pname=request.getParameter("pname");
		 String desc=request.getParameter("desc");
		 String manufacturingdate=request.getParameter("mdate");
		 String expirydate=request.getParameter("edate");
		 String mrp=request.getParameter("mrp");
		 String category=request.getParameter("category");
		 String subcategory=request.getParameter("subcategory");
		 String supplier=request.getParameter("supplier");
		String qty=request.getParameter("qty");
		String rating=request.getParameter("rating");
		String[] Discount=request.getParameterValues("discount");
		
		/*System.out.println(pname);
		System.out.println(desc);
		System.out.println(manufacturingdate);
		System.out.println(expirydate);
		System.out.println(mrp);
		System.out.println(category);
		System.out.println(subcategory);
		System.out.println(supplier);
		System.out.println(qty);
		System.out.println(rating);
		System.out.println(Discount);*/
	 	 Product product=new Product();
		product.setProductName(pname);
		product.setDescription(desc);
		
		SimpleDateFormat myFormat=new SimpleDateFormat("yyyy-MM-dd");
		Date mdate=null;
		Date edate=null;
		try {
			mdate=myFormat.parse(manufacturingdate);
			edate=myFormat.parse(expirydate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 product.setManufacturing_date(mdate);//dd-MMM-yyyy
     product.setExpiry_date(edate);//dd-MMM-yyyy
     product.setMax_retail_price(Double.parseDouble(mrp));
     product.setQuantity(Integer.parseInt(qty));
     product.setRatings(Float.parseFloat(rating));
     
     IProductDao db=new ProductDaoImplForJdbc();
       // List All Category
        Category cat=new Category();
   		cat.setCategory_Id(Integer.parseInt(category));
   		product.setCategory(cat);
   		// List All SubCategory
   		SubCategory sub = null;
   		List<SubCategory> listSubCategory = db.getAllSubCategory();
   		for (SubCategory subCategory : listSubCategory) {
   			if (subCategory.getSub_category_Id() == Integer.parseInt(subcategory))
   				sub = subCategory;
   			product.setSubCategory(sub);
   		}
   		// List All Supplier
   		Supplier sup = null;
   		List<Supplier> listSupplier = db.getAllSupplier();
   		for (Supplier supplier1 : listSupplier) {
   			if (supplier1.getSupplier_Id() == Integer.parseInt(supplier))
   				sup = supplier1;
   			product.setSupplier(sup);
   		}

   		/*String[] Discount=request.getParameterValues("discount");*/
   		List<Discount> appliedDiscounts = new ArrayList<>();
   		for(Discount discount:db.getAllDiscount())
   			for(String iD: Discount)
   				if(Integer.parseInt(iD)==discount.getDiscount_Id())
   					appliedDiscounts.add(discount);
   		
   		product.setDiscounts(appliedDiscounts);
   		
   	boolean flag=db.addProduct(product);
   	RequestDispatcher rd=request.getRequestDispatcher("Record Inserted");
   	if(flag==true)
   	{
   		rd.forward(request, response);
   	}
   	else
   	{
   		System.out.println("error");
   	} 
   		
 

   	}
		
	}


