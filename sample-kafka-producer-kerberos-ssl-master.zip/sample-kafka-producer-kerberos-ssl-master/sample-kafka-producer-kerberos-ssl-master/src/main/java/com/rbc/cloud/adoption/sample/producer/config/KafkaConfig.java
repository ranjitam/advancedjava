package com.rbc.cloud.adoption.sample.producer.config;

import com.rbc.cloud.adoption.sample.avro.CreditCardTransaction;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;

import javax.annotation.Resource;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Properties;

/**
 * Created by lojones on 27/09/2017.
 */
@Configuration
@PropertySource(value = "classpath:application.properties")
public class KafkaConfig {
    @Resource
    private Environment env;
    @Autowired
    private ResourceLoader resourceLoader;

    @Bean
    Producer<String, CreditCardTransaction> producer() throws Exception {
        final Properties props = new Properties();
        props.put("client.id", InetAddress.getLocalHost().getHostName());
        props.put("bootstrap.servers", env.getProperty("kafka.bootstrap.servers"));
        props.put("acks", "all");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", KafkaAvroSerializer.class.getName());
        props.put("schema.registry.url",env.getProperty("kafka.schema.registry.url"));

        String jaasFile=env.getProperty("jaasfile");
        System.out.println("Jaas file is "+jaasFile);

        if (jaasFile != null) {
            props.put("security.protocol", env.getProperty("security.protocol"));
            props.put("sasl.kerberos.service.name", env.getProperty("sasl.kerberos.service.name"));

            try {
                System.setProperty("java.security.auth.login.config", this.resourceLoader.getResource(jaasFile).getURI().toString());
                System.setProperty("java.security.krb5.realm", env.getProperty("realm"));
                System.setProperty("java.security.krb5.kdc", env.getProperty("kdc"));
                System.setProperty("sun.security.krb5.debug", env.getProperty("krb.debug"));
                System.setProperty("sun.security.krb5.principal", env.getProperty("principal"));
            } catch (IOException var3) {
                var3.printStackTrace();
            }
        }

        if (env.getProperty("security.protocol").equals("SASL_SSL")) {
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, env.getProperty("truststore.location"));
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, env.getProperty("truststore.password"));
        }

        System.out.println("******Producer props*******:");
        System.out.println(props.toString());
        return new KafkaProducer<>(props);
    }

}


