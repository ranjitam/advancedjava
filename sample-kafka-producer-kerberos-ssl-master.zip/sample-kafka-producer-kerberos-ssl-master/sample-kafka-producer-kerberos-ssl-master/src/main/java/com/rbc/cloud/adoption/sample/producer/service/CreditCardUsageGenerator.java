package com.rbc.cloud.adoption.sample.producer.service;

import com.rbc.cloud.adoption.sample.avro.CreditCardTransaction;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Logger;

/**
 * Created by lojones on 26/09/2017.
 */
@Component
public class CreditCardUsageGenerator {

    private Logger logger = Logger.getLogger(CreditCardUsageGenerator.class.getName());
    Long counter = 0L;
    Random random = new Random();
    Vector<String> clientNames = new Vector<String>();
    Vector<String> retailerNames = new Vector<String>();
    List<String> currencies  = Arrays.asList("CAD","USD","EUR","GBP");

    @Autowired
    private Producer<String, CreditCardTransaction> producer;

    private BlockingQueue<CreditCardTransaction> transactions = new ArrayBlockingQueue<CreditCardTransaction>(1000);


    private String getNextTxnId() {
        return String.valueOf(counter++) + "-" + String.valueOf(System.currentTimeMillis());
    }

    public CreditCardUsageGenerator() {
        clientNames = loadFile("client-names.txt"); //loadClientNames();
        retailerNames = loadFile("retailer-names.txt"); //loadClientNames();
    }

    private void loadClientNames() {
        try {
            File file = new File(getClass().getClassLoader().getResource("client-names.txt").getFile());
            Scanner s = new Scanner(file);
            if (s.hasNext()) { s.nextLine(); }
            while (s.hasNext()){
                clientNames.add(s.nextLine());
            }
            s.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private Vector<String> loadFile(String filename) {
        Vector<String> target = new Vector<String>();
        try {

            File file = new File(getClass().getClassLoader().getResource(filename).getFile());
            Scanner s = new Scanner(file);
            if (s.hasNext()) { s.nextLine(); }
            while (s.hasNext()){
                target.add(s.nextLine());
            }
            s.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return target;
    }

    public String getNextName() {
        int index = random.nextInt(clientNames.size());
        return clientNames.get(index);
    }

    private Integer getNextAmout() {
        return random.nextInt(2000);
    }

    private String getNextCcy() {
        int index = random.nextInt(currencies.size());
        return currencies.get(index);
    }

    private String getNextPayee() {
        int index = random.nextInt(retailerNames.size());
        return retailerNames.get(index);
    }

    private CreditCardTransaction getNextTxn() {
        CreditCardTransaction creditCardTxn = new CreditCardTransaction();
        creditCardTxn.setTransactionID(getNextTxnId());
        creditCardTxn.setAmount(getNextAmout());
        creditCardTxn.setCustomerName(getNextName());
        creditCardTxn.setCurrency(getNextCcy());
        creditCardTxn.setPayee(getNextPayee());
        creditCardTxn.setTimestamp(DateTime.now());
        logger.info("Generated credit card transaction: " + ReflectionToStringBuilder.toString(creditCardTxn, ToStringStyle.SIMPLE_STYLE));
        return creditCardTxn;
    }

    @Value("${topic}")
    String topicName;

    private void publishTransaction() {
        CreditCardTransaction transaction = getNextTxn();
        String key=transaction.getTransactionID().toString();
        ProducerRecord<String, CreditCardTransaction> producerRecord = new ProducerRecord<>(topicName,key,transaction);
        producer.send(producerRecord);
        transactions.add(transaction);
        logger.info("Published "+key);
    }

    private int getSleepMillisBetweenTransactions() {
        int seconds = random.nextInt(5)+1;
        return seconds * 1000;
    }

    private void waitBetweenTransactions() throws InterruptedException {
        int sleepTime=getSleepMillisBetweenTransactions();
        logger.info("Sleep for millis "+sleepTime);
        Thread.sleep(sleepTime);
    }

//    @PostConstruct
//    public void simulateCreditCardTransactions() {
//        try {
//            while (true) {
//                waitBetweenTransactions();
//                publishTransaction();
//            }
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//            logger.info("Exiting");
//        }
//    }

    @PostConstruct
    public void simulate() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        waitBetweenTransactions();
                        publishTransaction();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    logger.info("Exiting");
                }
            }
        });
        thread.start();
    }

    public String getTransactions() {
        StringBuilder sb=new StringBuilder();
        synchronized (transactions) {
            for (CreditCardTransaction t : transactions) {
                sb.insert(0,t.toString());
                sb.insert(0,"<br />");
            }
            if (transactions.size()==0) {
                sb.append("Nothing yet...");
                sb.insert(0,"<br />");
            }
        }
        sb.insert(0,"---------------------------");
        sb.insert(0,"<br />");
        sb.insert(0,"<h1>Producer - Published messages</h1>");
        sb.insert(0,"<br />");
        sb.insert(0,"Ctrl+R to Refresh");

        return sb.toString();

    }
}
