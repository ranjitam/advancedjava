package com.rbc.cloud.adoption.sample.producer.config;

import com.rbc.cloud.adoption.sample.avro.CreditCardTransaction;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import javax.annotation.Resource;
import java.net.InetAddress;
import java.util.Properties;

/**
 * Created by lojones on 27/09/2017.
 */
@Configuration
@PropertySource(value = "classpath:application.properties")
public class KafkaConfig {
    @Resource
    private Environment env;

    @Bean
    Producer<String, CreditCardTransaction> producer() throws Exception {
        final Properties config = new Properties();
        config.put("client.id", InetAddress.getLocalHost().getHostName());
        config.put("bootstrap.servers", env.getProperty("kafka.bootstrap.servers"));
        config.put("acks", "all");
        config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        config.put("value.serializer", KafkaAvroSerializer.class.getName());
        config.put("schema.registry.url",env.getProperty("kafka.schema.registry.url"));
        System.out.println("******Producer config*******:");
        System.out.println(config.toString());
        return new KafkaProducer<>(config);
    }

}


